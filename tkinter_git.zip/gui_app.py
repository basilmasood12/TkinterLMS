import tkinter as tk
from tkinter import messagebox, simpledialog
from book_library import Book, EBook, Library, BookNotAvailableError


library_system = Library()


main_window = tk.Tk()
main_window.title("Library Manager")
main_window.geometry("600x600")



def handle_add_book():
    book_title = input_title.get()
    book_author = input_author.get()
    book_isbn = input_isbn.get()
    is_digital = digital_var.get()
    download_mb = input_size.get()

    if not book_title or not book_author or not book_isbn:
        messagebox.showerror("Error", "Title, Author, and ISBN must be filled in.")
        return

    if is_digital and not download_mb:
        messagebox.showerror("Error", "Download size required for digital books.")
        return

    if is_digital:
        new_book = EBook(book_title, book_author, book_isbn, download_mb)
    else:
        new_book = Book(book_title, book_author, book_isbn)

    library_system.add_book(new_book)
    messagebox.showinfo("Success", f"'{book_title}' has been added.")
    refresh_book_list()

def handle_lend_book():
    requested_isbn = simpledialog.askstring("Lend Book", "Enter ISBN to lend:")
    if requested_isbn:
        try:
            library_system.lend_book(requested_isbn)
            messagebox.showinfo("Success", "Book has been lent.")
            refresh_book_list()
        except BookNotAvailableError as ex:
            messagebox.showerror("Error", str(ex))

def handle_return_book():
    return_isbn = simpledialog.askstring("Return Book", "Enter ISBN to return:")
    if return_isbn:
        try:
            library_system.return_book(return_isbn)
            messagebox.showinfo("Success", "Book successfully returned.")
            refresh_book_list()
        except BookNotAvailableError as ex:
            messagebox.showerror("Error", str(ex))

def handle_remove_book():
    delete_isbn = simpledialog.askstring("Remove Book", "Enter ISBN to remove:")
    if delete_isbn:
        library_system.remove_book(delete_isbn)
        messagebox.showinfo("Success", "Book has been removed.")
        refresh_book_list()

def search_books_by_author():
    query_author = simpledialog.askstring("Find by Author", "Enter author name:")
    if query_author:
        author_books = list(library_system.books_by_author(query_author))
        if author_books:
            list_display.delete(0, tk.END)
            list_display.insert(tk.END, f"Books by {query_author}:")
            for b in author_books:
                list_display.insert(tk.END, str(b))
        else:
            messagebox.showinfo("No Results", "No books found for this author.")

def refresh_book_list():
    list_display.delete(0, tk.END)
    list_display.insert(tk.END, "Currently Available Books:")
    for b in library_system:
        list_display.insert(tk.END, str(b))




tk.Label(main_window, text="Title:").pack()
input_title = tk.Entry(main_window)
input_title.pack()


tk.Label(main_window, text="Author:").pack()
input_author = tk.Entry(main_window)
input_author.pack()


tk.Label(main_window, text="ISBN:").pack()
input_isbn = tk.Entry(main_window)
input_isbn.pack()


digital_var = tk.BooleanVar()
tk.Checkbutton(main_window, text="Is Digital?", variable=digital_var).pack()


tk.Label(main_window, text="File Size (MB):").pack()
input_size = tk.Entry(main_window)
input_size.pack()


tk.Button(main_window, text="Add Book", command=handle_add_book).pack(pady=5)
tk.Button(main_window, text="Lend Book", command=handle_lend_book).pack(pady=5)
tk.Button(main_window, text="Return Book", command=handle_return_book).pack(pady=5)
tk.Button(main_window, text="Remove Book", command=handle_remove_book).pack(pady=5)
tk.Button(main_window, text="Search Books by Author", command=search_books_by_author).pack(pady=5)


tk.Label(main_window, text="Book Inventory:").pack()
list_display = tk.Listbox(main_window, width=70)
list_display.pack(pady=10)


refresh_book_list()


main_window.mainloop()
